# DigitalMedia

### No pude dockerizar

## Ports

```
Keycloak: 8082
Eureka: 8761
Gateway: 8080
Movies: 8086
Users: 8087
Bills: 8088
```

## gateway-api

### Use the browser to test the gateway-api microservice
